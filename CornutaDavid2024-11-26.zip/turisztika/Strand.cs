﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turisztika
{
    internal class Strand : latvanyossag
    {
        public Strand(string orszag, string varos, string megnevezes, int nyitvaKezdete, int nyitvaVege, bool zart, List<string> csuszdak, double arOrankent):base(orszag, varos, megnevezes, nyitvaVege, nyitvaKezdete)
        {
            Zart = zart;
            Csuszdak = csuszdak;
            this.arOrankent = arOrankent;
        }

        public bool Zart { get; set; }
        public List<string> Csuszdak { get; set; }
        public double arOrankent {  get; set; } 


        public  void CsuszdaHozzaad(string csuszda)
        {
            Csuszdak.Add(csuszda);
        }

        public virtual void CsuszdaHozzaad(List<string> csuszdak)
        {
            foreach (string s in csuszdak)
            {
                Csuszdak.Add(s);
            }
        }
    }
}
