function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
  }
let avg = 0;
let values = 0;
let alldb = 0;
let mimicdb = 0;
let mimic = 0;
let karddb = 0;
let kard = 0;
let pajzs = 0;
let pajzsdb = 0;
let anyag = 0;
let anyagdb = 0;


function Show()
{
    let level =1 * document.getElementById("level").value;
    let chestNumber = 1 * document.getElementById("chests").value; 


    for(let i = 0; i < chestNumber; i++)
    {
        let d = Number(getRndInteger(1,10))
        if(d == 10)
        {
            console.log(d)
            mimicdb  += 1;
            mimic = level*-10
            document.getElementById("items").innerHTML +=
            `
            <div class="col-12 col-md-6 col-lg-3">
            
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Mimic</h4>
                        <p class="card-text">Value: ${mimic}</p>
                    </div>
                </div>
            </div>
            ` 
            document.getElementById("mimic").innerText = mimicdb
        }
        
         else if(d == 9 || d == 8 || d == 7)
        {
            alldb++;
            karddb ++;
            kard = level*getRndInteger(10, 20);
            values += kard
            document.getElementById("items").innerHTML +=
            `
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Sword</h4>
                        <p class="card-text">Value: ${kard}</p>
                    </div>
                </div>
            </div>
            `
            document.getElementById("sword").innerText = karddb
        }

        else if(d == 6 || d == 5 || d == 4)
        {
            alldb++;  
            pajzsdb++;
            pajzs = level*getRndInteger(10, 20);
            values += pajzs
            document.getElementById("items").innerHTML +=
            `
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Shield</h4>
                        <p class="card-text">Value: ${pajzs}</p>
                    </div>
                </div>
            </div>
            ` 
            document.getElementById("shield").innerText = pajzsdb;
        }

        else if (d == 3 || d == 2 || d == 1)
        {
            alldb++;
            anyagdb++;
            anyag = level*getRndInteger(0, 15); //kicsit más legyen mint a többi értéke
            values += anyag
            document.getElementById("items").innerHTML +=
            `
            <div class="col-12 col-md-6 col-lg-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Material</h4>
                        <p class="card-text">Value: ${anyag}</p>
                    </div>
                </div>
            </div>
            ` 
            document.getElementById("material").innerText = anyagdb;
        }
        
    }
        avg = values/alldb  
        document.getElementById("avg").innerText = Math.round(avg)
}