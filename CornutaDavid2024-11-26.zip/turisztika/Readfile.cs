﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turisztika
{
    internal class Readfile
    {
        List<latvanyossag> list;

        public Readfile()
        {
            list = [];
        }

        public void Beolvas(string file)
        {
            foreach (var i in File.ReadLines(file,Encoding.UTF8))
            {
                var parts = i.Split(";");
                string orszag = parts[1];
                string varos = parts[2];
                string megnevezes = parts[3];
                int nyitvaKezdete = int.Parse(parts[4]);
                int nyitvaVege = int.Parse(parts[5]);

                switch (parts[0])
                {
                    case "m":
                        string tema = parts[6];
                        bool jogosultIngyenesUtazásra;
                        if (parts[7] == "igen")
                        {  jogosultIngyenesUtazásra = true; }
                        else { jogosultIngyenesUtazásra = false; }
                        double belepo = Convert.ToDouble(parts[8]);
                        list.Add( new Muzeum(orszag, varos, megnevezes, nyitvaKezdete, nyitvaVege, tema, jogosultIngyenesUtazásra, belepo));
                        break;

                    case "s":
                        bool zart;
                        if (parts[6] == "igen") {  zart = true; } else { zart = false; }
                        List<string> csuszdak = [];
                        csuszdak.AddRange(parts[7].Split(','));
                        double arOrankent = Convert.ToDouble(parts[8]);
                        list.Add(new Strand(orszag,varos,megnevezes,nyitvaKezdete,nyitvaVege,zart,csuszdak,arOrankent));
                        break;

                    case "gy":
                        {
                            zart = false;
                            csuszdak = [];
                            csuszdak.AddRange(parts[7].Split(','));
                            arOrankent = Convert.ToDouble(parts[8]);
                            int korhatar = Convert.ToInt32(parts[9]);
                            bool masszas;
                            if (parts[10] == "igen") { masszas = true; } else { masszas = false; }
                            list.Add(new Gyogyfurdo(orszag, varos, megnevezes, nyitvaKezdete, nyitvaVege, zart, csuszdak, arOrankent, korhatar, masszas));
                            break;
                        }
                }
            }
        }
    }
}
