﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turisztika
{
    internal class Muzeum : latvanyossag
    {
        public Muzeum(string orszag, string varos, string megnevezes, int nyitvaKezdete, int nyitvaVege, string tema, bool jogosultIngyenesUtazásra, double belepo) : base(orszag, varos, megnevezes, nyitvaVege,nyitvaKezdete)
        {
            Tema = tema;
            this.jogosultIngyenesUtazásra = jogosultIngyenesUtazásra;
            this.belepo = belepo;
        }

        public string Tema { get; set; }
        public bool jogosultIngyenesUtazásra { get; set; }
        public double belepo { get; set; }


        public double CsoportosKedvezmeny(int letszam)
        {
            if (letszam < 10) { return belepo; }
            else if (letszam < 20) { return belepo * 0.8; }
            else { return belepo * 0.7;}
        }

    }
}
