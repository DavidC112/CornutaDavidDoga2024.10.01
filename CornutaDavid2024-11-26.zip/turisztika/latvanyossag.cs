﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turisztika
{
    internal abstract class latvanyossag
    {
        protected latvanyossag(string orszag, string varos, string megnevezes, int nyitvaKezdete, int nyitvaVege)
        {
            Orszag = orszag;
            Varos = varos;
            Megnevezes = megnevezes;
            this.nyitvaKezdete = nyitvaKezdete;
            this.nyitvaVege = nyitvaVege;
        }

        public string Orszag { get; set; }
        public string Varos {  get; set; }
        public string Megnevezes { get; set; }  
        public int nyitvaKezdete { get; set; }
        public int nyitvaVege { get; set; }

        protected latvanyossag(string orszag, string varos, string megnevezes)
        {
            Orszag = orszag;
            Varos = varos;
            Megnevezes = megnevezes;
            this.nyitvaKezdete = 0;
            this.nyitvaVege = 24;
        }


    }
}
