﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace turisztika
{
    internal class Gyogyfurdo : Strand
    {
        public Gyogyfurdo(string orszag, string varos, string megnevezes, int nyitvaVege, int nyitvaKezdete,  bool zart, List<string> csuszdak, double arOrankent,   int korhatar, bool masszazs) :base(orszag, varos, megnevezes, nyitvaKezdete, nyitvaVege, zart,csuszdak,arOrankent)
        {
            Korhatar = korhatar;
            Masszazs = masszazs;
            csuszdak = [];
        }

        public int Korhatar { get; set; }
        public bool Masszazs {  get; set; }

    }
}
